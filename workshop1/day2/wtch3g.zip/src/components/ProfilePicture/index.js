import ProfilePicture from "./View";

export default ProfilePicture;
