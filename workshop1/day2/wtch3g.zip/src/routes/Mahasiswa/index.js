import Mahasiswa from "./View";

export default Mahasiswa;