import ProfileMahasiswa from "./View";

export default ProfileMahasiswa;