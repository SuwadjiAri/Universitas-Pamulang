#include <iostream>
using namespace std;

int main (){
    cout << "TUGAS ALGORITMA DAN PEMROGRAMAN I" << endl;
    cout << "KELOMPOK I\n" << endl;
    cout << "1. Arif Frima Ari Suwadji - 221011700443" << endl;
    cout << "2. Dipa Sonata - 221011700093" << endl;
    cout << "3. Noufal Farhan - 221011700463" << endl;
    cout << "4. Rangga Dwi Mardika - 221011700473" << endl;
    cout << "5. Rini Safitri - 221011700088\n" << endl;
	cout << "PROGRAM C++ MENGHITUNG LUAS PERSEGI PANJANG" << endl;
	cout << "============================================" << endl;
    cout << endl;

	float luas,panjang,lebar;
    
	cout << "Masukan Panjang Persegi Panjang: ";
	cin >> panjang;
	cout << "Masukan Lebar Persegi Panjang: ";
	cin >> lebar;
	luas=panjang*lebar;
	cout << "Luas Persegi Panjang adalah\t: " << luas << endl;
	return 0;
}